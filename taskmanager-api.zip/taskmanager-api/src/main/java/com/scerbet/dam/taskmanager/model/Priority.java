package com.scerbet.dam.taskmanager.model;

public enum Priority {
    BAJA, MEDIA, ALTA
}
